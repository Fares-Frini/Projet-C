#include <gtk/gtk.h>


void
on_register_button_clicked  (GtkWidget *objet_graphique, gpointer user_data);
