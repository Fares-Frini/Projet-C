#include <gtk/gtk.h>

void on_recherche_clicked(GtkWidget *objet_graphique, gpointer user_data);
